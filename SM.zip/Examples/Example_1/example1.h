typedef void State;
typedef State (*Pstate)();

